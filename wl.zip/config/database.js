module.exports = {
    database: "mongodb+srv://razvanul:1234@cluster0-lrrsf.mongodb.net/statistics?retryWrites=true",
    secret: "supremul consiliu"
}